
class Laboratorio: 
   
        def _init_(self, id, nome, specializzazione, responsabile):
        
            self.id = id 
            self.nome = nome 
            self.specializzazione = specializzazione 
            self.responsabile = responsabile 

        def set_id (self, id):
            self.id = id 
       
        def set_nome (self, nome):
            self.nome = nome
       
        def set_specializzazione (self, specializzazione):
            self.specializzazione = specializzazione
       
        def set_responsabile (self, responsabile):
            self.responsabile = responsabile 
          
        def get_id (self):
            return self.id 

        def get_nome (self):
            return self.nome 

        def get_specializzazione (self):
            return self.specializzazione 

        def get_responsabile (self):
            return self.responsabile
        
        def lista (self):
         lista = []
         lista.append(self.id)
         lista.append(self.nome)
         lista.append(self.specializzazione)
         lista.append(self.responsabile)
         return lista
  
  
    