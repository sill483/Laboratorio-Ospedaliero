import tkinter as tk
from tkinter import ttk, messagebox
from gestioneLaboratorio import GestioneLaboratorio 
import csv

specializzazioneLab = [" ", "Ecografia", "Cardiologia", "Radiologia"]
apparechiatureLab = [" ","Ecografo", "Risonanza Magnetica", "Raggi X"]
disponibilitaLab = [" ", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato","Domenica"]

gestioneLab = GestioneLaboratorio()

class Interfaccialabb:
 
 def __init__(self):
  pass

def aggiungi_laboratorio():

  id_input = id_entry.get()

  if not id_input.isdigit():
      messagebox.showerror("Errore", "L'ID deve essere un numero intero.")
      return
  
  id = int(id_input)
  nome = nome_entry.get()
  specializzazioneLab = specializzazione_combobox.get()
  responsabile = responsabile_entry.get()
  apparecchiatureLab = apparecchiature_combobox.get()
  disponibilitaLab = disponibilita_combobox.get()

  if disponibilitaLab in ["Lunedì", "Martedì", "Giovedì"] and specializzazioneLab == "Ecografia":
        messagebox.showinfo("Successo", "Disponibile Laboratorio Ecografia")
  elif disponibilitaLab in ["Mercoledì", "Lunedì", "Venerdì"] and specializzazioneLab == "Cardiologia":
        messagebox.showinfo("Successo", "Disponibile Laboratorio Cardiologia")
  elif disponibilitaLab in ["Mercoledì", "Giovedì", "Venerdì"] and specializzazioneLab == "Radiologia":
        messagebox.showinfo("Successo", "Disponibile Laboratorio Radiologia")
  else:
        messagebox.showerror("Errore", "Ci dispiace, il Laboratorio non è disponibile.")
        return
    
  with open("laboratori.csv", "a", newline='') as file:
        writer = csv.writer(file)
        writer.writerow([id, nome, specializzazioneLab, responsabile, apparecchiatureLab, disponibilitaLab])
    
  tabella.insert('', 'end', text=id, values=(nome, specializzazioneLab, responsabile, apparecchiatureLab, disponibilitaLab))
  messagebox.showinfo("Successo", "Laboratorio aggiunto con successo.")

def creazione_laboratorio():
    
  aggiungi_finestra = tk.Toplevel(finestra)
  aggiungi_finestra.title ("Aggiungi dati")
  aggiungi_finestra.geometry("600x350")

  global id_entry, nome_entry, specializzazione_combobox, responsabile_entry, apparecchiature_combobox, disponibilita_combobox

  id_label = tk.Label(aggiungi_finestra, text = "id:", font = ("calibri"))
  id_label.grid(row = 0, column = 0, sticky = tk.W, padx = 10, pady = 10)
  id_entry = tk.Entry (aggiungi_finestra, width = 30)
  id_entry.focus_set()
  id_entry.grid(row = 0, column = 1, sticky = tk.EW, ipady = 5)

  nome_label = tk.Label(aggiungi_finestra, text = "nome:", font = ("calibri"))
  nome_label.grid(row = 1, column = 0, sticky = tk.W, padx = 10, pady = 10)
  nome_entry = tk.Entry (aggiungi_finestra, width = 30)
  nome_entry.focus_set()
  nome_entry.grid(row = 1, column = 1, sticky = tk.EW, ipady = 5)


  specializzazione_label = tk.Label(aggiungi_finestra, text = "specializzazione:", font = ("calibri"))
  specializzazione_label.grid (row = 2, column = 0, sticky = tk.W, padx = 10, pady = 10)
  specializzazione_combobox = ttk.Combobox (aggiungi_finestra, values = specializzazioneLab, width = 30)
  specializzazione_combobox.current(0)
  specializzazione_combobox.grid (row = 2, column = 1, sticky = tk.EW, ipady = 5)
  

  responsabile_label= tk.Label(aggiungi_finestra, text = "responsabile:", font = ("calibri"))
  responsabile_label.grid (row = 3, column = 0, sticky = tk.W, padx = 10, pady = 10)
  responsabile_entry = tk.Entry (aggiungi_finestra, width = 30)
  responsabile_entry.focus_set()
  responsabile_entry.grid  (row = 3, column = 1, sticky = tk.EW, ipady = 5)
    

  apparechiature_label = tk.Label(aggiungi_finestra, text = "apparecchiature:", font = ("calibri"))
  apparechiature_label.grid (row = 4, column = 0, sticky = tk.W, padx = 10, pady = 10)
  apparecchiature_combobox = ttk.Combobox (aggiungi_finestra, values= apparechiatureLab, width = 30)
  apparecchiature_combobox.current(0)
  apparecchiature_combobox.grid(row=4, column=1, sticky=tk.EW)


  diponibilita_label = tk.Label(aggiungi_finestra, text = "disponibilità:", font = ("calibri"))
  diponibilita_label.grid (row = 5, column = 0, sticky = tk.W, padx = 10, pady = 10)
  disponibilita_combobox = ttk.Combobox(aggiungi_finestra, values= disponibilitaLab, width = 30)
  disponibilita_combobox.current(0)
  disponibilita_combobox.grid (row = 5, column = 1, sticky = tk.EW, ipady = 5)
    
  pulsante = tk.Button(aggiungi_finestra, text="invia", command= aggiungi_laboratorio, width=20, height=2 )
  pulsante.grid (sticky= tk.SW)


def modifica_dati():

    global finestra_modifica, id_entry, nome_entry, specializzazione_combobox, responsabile_entry, apparecchiature_combobox, disponibilita_combobox

    finestra_modifica = tk.Toplevel(finestra)
    finestra_modifica.title ("Modifica dati laboratorio")
    finestra_modifica.geometry("400x300")

    id_label = tk.Label(finestra_modifica, text="ID:")
    id_label.grid(row=0, column=0, padx=5, pady=5)
    id_entry = tk.Entry(finestra_modifica)
    id_entry.grid(row=0, column=1, padx=5, pady=5)

    nome_label = tk.Label(finestra_modifica, text="Nome:")
    nome_label.grid(row=1, column=0, padx=5, pady=5)
    nome_entry = tk.Entry(finestra_modifica)
    nome_entry.grid(row=1, column=1, padx=5, pady=5)

    specializzazione_label = tk.Label(finestra_modifica, text="Specializzazione:")
    specializzazione_label.grid(row=2, column=0, padx=5, pady=5)
    specializzazione_combobox = ttk.Combobox (finestra_modifica, values = specializzazioneLab, width = 30)
    specializzazione_combobox.current(0)
    specializzazione_combobox.grid (row = 2, column = 1, sticky = tk.EW, ipady = 5)

    responsabile_label = tk.Label(finestra_modifica, text="Responsabile:")
    responsabile_label.grid(row=3, column=0, padx=5, pady=5)
    responsabile_entry = tk.Entry(finestra_modifica)
    responsabile_entry.grid(row=3, column=1, padx=5, pady=5)

    apparecchiature_label = tk.Label(finestra_modifica, text="Apparecchiature:")
    apparecchiature_label.grid(row=4, column=0, padx=5, pady=5)
    apparecchiature_combobox = ttk.Combobox (finestra_modifica, values= apparechiatureLab, width = 30)
    apparecchiature_combobox.current(0)
    apparecchiature_combobox.grid(row=4, column=1, sticky=tk.EW)
    

    disponibilita_label = tk.Label(finestra_modifica, text="Disponibilità:")
    disponibilita_label.grid(row=5, column=0, padx=5, pady=5)
    disponibilita_combobox = ttk.Combobox(finestra_modifica, values= disponibilitaLab, width = 30)
    disponibilita_combobox.current(0)
    disponibilita_combobox.grid (row = 5, column = 1, sticky = tk.EW, ipady = 5)

    aggiorna_button = tk.Button(finestra_modifica, text="Aggiorna", command= aggiorna_tabella)
    aggiorna_button.grid(row=6, columnspan=2, padx=5, pady=5)


def aggiorna_tabella():
   seleziona_index = tabella.focus()
   new_id = id_entry.get()
   new_nome = nome_entry.get()
   new_specializzazione = specializzazione_combobox.get()
   new_responsabile = responsabile_entry.get()
   new_apparecchiature = apparecchiature_combobox.get()
   new_disponibilita = disponibilita_combobox.get()
    
   tabella.item(seleziona_index, values=(new_id, new_nome, new_specializzazione, new_responsabile, new_apparecchiature, new_disponibilita))
   messagebox.showinfo("Successo", "Dati aggiornati correttamente.")
   finestra_modifica.destroy()

   
def seleziona_tabella(event):
    seleziona_index = tabella.focus()
    id_entry.delete(0, 'end')
    id_entry.insert(0, tabella.item(seleziona_index, 'values')[0])
    nome_entry.delete(0, 'end')
    nome_entry.insert(0, tabella.item(seleziona_index, 'values')[1])
    specializzazione_combobox.delete(0, 'end')
    specializzazione_combobox.insert(0, tabella.item(seleziona_index, 'values')[2])
    responsabile_entry.delete(0, 'end')
    responsabile_entry.insert(0, tabella.item(seleziona_index, 'values')[3])
    apparecchiature_combobox.delete(0, 'end')
    apparecchiature_combobox.insert(0, tabella.item(seleziona_index, 'values')[4])
    disponibilita_combobox.delete(0, 'end')
    disponibilita_combobox.insert(0, tabella.item(seleziona_index, 'values')[5])


def visualizza_dati_lab():
    finestra_visualizza = tk.Toplevel(finestra)
    finestra_visualizza.title("Visualizza dati laboratorio")
    finestra_visualizza.geometry("800x400")

    tabella_visualizza = ttk.Treeview(finestra_visualizza, columns=("Nome", "Specializzazione", "Responsabile", "Apparecchiature", "Disponibilità"))
    tabella_visualizza.heading ("#0", text = "id")
    tabella_visualizza.column("#0", width= 150)
    tabella_visualizza.heading("Nome", text="Nome")
    tabella_visualizza.column("Nome", width=150)
    tabella_visualizza.heading("Specializzazione", text="Specializzazione")
    tabella_visualizza.column("Specializzazione", width=150)
    tabella_visualizza.heading("Responsabile", text="Responsabile")
    tabella_visualizza.column("Responsabile", width=150)
    tabella_visualizza.heading("Apparecchiature", text="Apparecchiature")
    tabella_visualizza.column("Apparecchiature", width=150)
    tabella_visualizza.heading("Disponibilità", text="Disponibilità")
    tabella_visualizza.column("Disponibilità", width=150)

    scrollbar_verticale = ttk.Scrollbar(finestra_visualizza, orient="vertical", command=tabella_visualizza.yview)
    scrollbar_verticale.pack(side="right", fill="y")

    scrollbar_orizzontale = ttk.Scrollbar(finestra_visualizza, orient="horizontal", command=tabella_visualizza.xview)
    scrollbar_orizzontale.pack(side="bottom", fill="x")

    tabella_visualizza.configure(yscrollcommand=scrollbar_verticale.set, xscrollcommand=scrollbar_orizzontale.set)

    tabella_visualizza.pack(fill="both", expand=True)

    with open("laboratori.csv", "r") as file:
        for line in file:
            record = line.strip().split(",")
            tabella_visualizza.insert("", "end", text=record[0], values=(record[1], record[2], record[3], record[4], record[5]))


def ricerca_laboratorio():
  ricerca_finestra = tk.Toplevel(finestra)
  ricerca_finestra.title ("ricerca id")
  ricerca_finestra.geometry("600x350")

  id_label = tk.Label(ricerca_finestra, text="ID:")
  id_label.grid(row=0, column=0, padx=10, pady=5, sticky="w")
  id_entry = tk.Entry(ricerca_finestra)
  id_entry.grid(row=0, column=1, padx=10, pady=5, sticky="we")

  specializzazione_label = tk.Label(ricerca_finestra, text="Specializzazione:")
  specializzazione_label.grid(row=1, column=0, padx=10, pady=5, sticky="w")
  specializzazione_entry = tk.Entry(ricerca_finestra)
  specializzazione_entry.grid(row=1, column=1, padx=10, pady=5, sticky="we")

  def prendi_campi():
    id = id_entry.get() 
    risultato = gestioneLab.ricerca_laboratorio_per_id(id)
    tk.Label(ricerca_finestra, text=risultato).grid(row=10, column=7, padx=10, pady=5, sticky="w")
  
  def prendi_spec():
     specializzazione =specializzazione_entry.get()
     risultato = gestioneLab.ricerca_specializzazione(specializzazione)
     tk.Label(ricerca_finestra, text=risultato).grid(row=14, column=10, padx=10, pady=5, sticky="w")


  conferma_button = tk.Button(ricerca_finestra, text="Ricerca ID", command = prendi_campi, width=15, height=2)
  conferma_button.grid(row=2, columnspan=2, pady=10)

  conferma_button1 = tk.Button(ricerca_finestra, text="Ricerca Specializzazione",command= prendi_spec ,width=15, height=2)
  conferma_button1.grid(row=3,columnspan=2, pady=10 )


def rimuovi_laboratorio():
    
    selection = tabella.selection()
    if not selection:
        messagebox.showerror("Errore", "Nessun laboratorio selezionato.")
        return
    
    id_selezionato = tabella.item(selection[0], "text")

    with open("laboratori.csv", "r",  newline='') as file:
        lines = file.readlines()
    with open("laboratori.csv", "w",  newline='') as file:
        writer = csv.writer(file)
        for line in lines:
            record = line.strip().split(",")
            if record[0] != id_selezionato:
                file.write(record)
    
    tabella.delete(selection)
    messagebox.showinfo("Successo", f"Laboratorio con ID {id_selezionato} rimosso correttamente.")
    

finestra = tk.Tk()

finestra.title("Gestione Laboratori")

finestra.geometry("1200x370")

tabella = ttk.Treeview(finestra, columns = ("nome", "specializzazione", "responsabile", "apparecchiature", "disponibilità"))
tabella.heading ("#0", text = "id")
tabella.column("#0", width= 150)
tabella.heading ("nome", text = "nome")
tabella.column("nome", width= 150)
tabella.heading ("specializzazione", text = "specializzazione")
tabella.column("specializzazione", width= 150)
tabella.heading ("responsabile", text = "responsabile")
tabella.column("responsabile", width= 150)
tabella.heading ("apparecchiature", text = "apparecchiature")
tabella.column("apparecchiature", width= 150)
tabella.heading ("disponibilità", text = "disponibilità")
tabella.column("disponibilità", width= 150)
tabella.place(x = 200, y = 60)

tabella.bind('<ButtonRelease-1>', seleziona_tabella)

pulsante = tk.Button(finestra, text="aggiungi", height = 2, width = 18, command= creazione_laboratorio)
pulsante.place(x = 50, y = 50)
pulsante.configure(background = "Light Gray")

pulsante = tk.Button(finestra, text="modifica", height = 2, width = 18, command= modifica_dati)
pulsante.place(x = 50, y = 100)
pulsante.configure(background = "Light Gray")


pulsante = tk.Button(finestra, text="visualizza", height = 2, width = 18, command= visualizza_dati_lab)
pulsante.place(x = 50, y = 150)
pulsante.configure(background = "Light Gray")

pulsante = tk.Button(finestra, text="rimuovi", height = 2, width = 18, command = rimuovi_laboratorio)
pulsante.place(x = 50, y = 200)
pulsante.configure(background = "Light Gray")

pulsante = tk.Button( finestra, text="ricerca", height = 2, width = 18, command = ricerca_laboratorio)
pulsante.place(x = 50, y = 250)
pulsante.configure(background = "Light Gray")

finestra.mainloop()

