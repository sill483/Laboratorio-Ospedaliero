
from laboratorio import Laboratorio

class Ecografia(Laboratorio):
    def _init_(self, id, nome, specializzazione, responsabile, apparecchiature, disponibilita):
       super()._init_(id, nome, specializzazione, responsabile)

       self.apparecchiature = apparecchiature
       self.disponibilita = disponibilita 
    
    def set_disponibilita (self, disponibilita):
          self.disponibilita = disponibilita

    def set_apparecchiature (self, apparecchiature):
          self.apparecchiature = apparecchiature

    def get_disponibilita (self):
        return self.disponibilita
    
    def get_apparecchiature (self):
        return self.apparecchiature
    
    def lista (self):
         lista = []
         lista.append(self.apparecchiature)
         lista.append(self.disponibilita)
         return lista
  
  
    