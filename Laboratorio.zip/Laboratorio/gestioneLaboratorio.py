import csv 

from laboratorio import Laboratorio 
from ecografia import Ecografia
from radiologia import Radiologia
from cardiologia import Cardiologia


class GestioneLaboratorio():
 
 file_csv = "laboratori.csv"

 def _init_(self):
    pass
 
 def aggiungi_laboratorio(self, file_csv, laboratorio):
    with open(file_csv, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(laboratorio.lista()) 


 def modifica_dati(self, file_csv, id, new_oggetto):
     oggetto = self.carica_dati(file_csv)
     for i, row in enumerate(oggetto):
         if row[0] == id:
             oggetto[i] = [id] + new_oggetto
             self.scrivi_dati(file_csv, oggetto)
             return True
         return False
             
 def ricerca_laboratorio_per_id(self, id_ricerca):
    risultati = self.ricerca_laboratorio(id_ricerca)
    return risultati  

 def ricerca_laboratorio(self, id_da_cercare):
    with open("laboratori.csv", "r") as file:
       reader = csv.reader (file) 
       for laboratorio in reader: 
          if id_da_cercare == laboratorio[0]:
             return Laboratorio(laboratorio[0],laboratorio[1], laboratorio[2], laboratorio[3])
    return False

 def ricerca_specializzazione(self, specializzazione):
    with open("laboratori.csv", "r") as file:
       lista_laboratori = []
       reader = csv.reader (file) 
       for laboratorio in reader: 
          if specializzazione == laboratorio[3]:
            
             lista_laboratori.append(Laboratorio(laboratorio[0],laboratorio[1], laboratorio[2], laboratorio[3]))
    return lista_laboratori

 def rimuovi_laboratorio(self, file_csv, id):
    oggetto = self.carica_dati(file_csv)
    new_oggetto = [row for row in oggetto if row[0] != id]
    if len(new_oggetto) < len(oggetto):
        self.scrivi_dati(file_csv, new_oggetto)
        return True
    else:
        return False

 def carica_dati(file_csv):
    with open(file_csv, mode='r') as file:
        reader = csv.reader(file)
        oggetto = list(reader)
    return oggetto

 def scrivi_dati(file_csv, oggetto):
    with open(file_csv, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(oggetto)   
  
    

#File csv per salvataggio e recupero dati: laboratori.csv


