 
from laboratorio import Laboratorio

class Radiologia(Laboratorio):
     def __init__(self, id, nome, specializzaione, responsabile, apparecchiature, disponibilita):
        super().__init__(id, nome, specializzaione, responsabile)

        self.apparecchiature = apparecchiature
        self.disponibilita = disponibilita

     def set_disponibilita (self, disponibilita):
        self.disponibilita = disponibilita
   
     def set_apparechiature (self, apparecchiature):
        self.apparecchiature = apparecchiature

     def get_disponibilita (self):
        return self.disponibilita 

     def get_apparecchiature (self):
        return self.apparecchiature

     def lista (self):
         lista = []
         lista.append(self.apparecchiature)
         lista.append(self.disponibilita)
         return lista
  
    